# Starterpack

## Intro
This _starterpack_ is a simple set of scripts and Docker files that download and run 
the containers needed to run the Gleaner workflow.  


