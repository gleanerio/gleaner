# Starterpack

## Intro
This _starterpack_ is a simple set of scripts and Docker files that download and run 
the containers needed to run the Gleaner workflow.  

This README is in flux but I will attempt to detail the configuration and support
scripts for a simple run.

I will also link here to a screencast showing the process in action.  

## Steps


